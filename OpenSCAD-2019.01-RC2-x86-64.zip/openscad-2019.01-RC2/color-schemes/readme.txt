Color Schemes
=============

Solarized
---------

http://ethanschoonover.com/solarized

Monokai
-------

http://www.monokai.nl/blog/2006/07/15/textmate-color-theme/

Tomorrow / Tomorrow Night
-------------------------

https://github.com/chriskempson/tomorrow-theme

Editor:

keyword1                Orange
keyword2                Purple
keyword3                Blue
comment                 Comment
commentline             Comment
commentdoc              Comment
commentdockeyword       Yellow
number                  Red
string                  Green
operator                Aqua
selection-foreground    Foreground
selection-background    Selection

Render:

opencsg-face-front      Blue
opencsg-face-back       Orange
cgal-face-front         Aqua
cgal-face-back          Yellow
cgal-face-2d            Green
cgal-edge-front         Foreground
cgal-edge-back          Foreground
cgal-edge-2d            Red
crosshair               Purple
